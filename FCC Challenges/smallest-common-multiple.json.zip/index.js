function smallestCommons(arr) {
//all numbers in between arr
let conA = Array.from(Array(Math.max(...arr) + 1).keys()).slice(Math.min(...arr));
//prime factors for each numbers
let result = conA.map(x => {
let newArr = [], i;
for (i = 2; i <= x; i++) {
  while ((x % i) === 0) {
    newArr.push(i);
      x /= i;
    }
  }
return newArr;
});

//unique numbers to check occurence
let resultStr = [].concat(...result); 
let uniqueArr = [...new Set(resultStr)];
//unique numbers to check
let beans = [];
uniqueArr.map(uni => {
//filter everything thats not the unique number
let end = result.map(x => x.filter(n => n == uni));
let countArr = end.map(en => en.length);
//find the max count and return the index of the unique number
let count = countArr.indexOf(Math.max(...countArr));
//get only the array containing the unique number and push it into master arr
let cool = end.slice(count, count+1);
beans.push(cool);
});

let newxD = [].concat(...beans);
let final = [].concat(...newxD);
let LCM = final.reduce((a , b) => a * b);


return LCM;
}

smallestCommons([23, 18]);

//for each number in the nest arrays, I want to match each number with all the other nest arrays to check occurence



//[ [ 2, 3, 3 ], [ 19 ], [ 2, 2, 5 ], [ 3, 7 ], [ 2, 11 ], [ 23 ] ]
//[ 2, 3, 19, 5, 7, 11, 23 ]