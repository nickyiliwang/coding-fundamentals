function truthCheck(collection, pre) {
  let x = collection.map(x => x.hasOwnProperty(pre));
  let y = collection.map(x => x[pre]);
  let n = [];

  if (y.indexOf(undefined) == -1 && y.indexOf('') == -1 && y.indexOf(null) == -1 && x.indexOf(false) == -1 && y.indexOf(0) == -1) {
    
    n = y.map(l => !Number.isNaN(l));
    return n.indexOf(false) == -1? true : false
    
} return false
}

truthCheck([{"single": "double"}, {"single": NaN}], "single")