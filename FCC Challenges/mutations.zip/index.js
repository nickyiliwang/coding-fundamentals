function mutation(arr) {
    let newArr = [];
    let firArr = [];
    let secArr = [];

    let arr1 = arr[0].toString().toLowerCase();
    let arr2 = arr[1].toString().toLowerCase();

    let letters1 = arr1.split("");
    let letters2 = arr2.split("");

    if (letters1.length > letters2.length) {
        firArr = letters1.slice(0, letters1.length);
        secArr = letters2.slice(0, letters2.length);
    } else if (letters1.length < letters2.length) {
        firArr = letters2.slice(0, letters2.length);
        secArr = letters1.slice(0, letters1.length);
    }

for (let i = 0; i < secArr.length; i++) {
if (firArr.indexOf(secArr[i]) == -1) {
  newArr.push(secArr[i]);
  
}
}
return newArr.length == 0 ? true : false;
}

mutation(["hello", "hey"]);