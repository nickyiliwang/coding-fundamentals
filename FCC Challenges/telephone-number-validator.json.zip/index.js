function telephoneCheck(str) {
  let newA = [];
  let regex1 = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;
  let regex2 = /^\([0-9]{3}\)[0-9]{3}-[0-9]{4}$/;
  let regex3 = /^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$/;
  let regex4 = /^[0-9]{3} [0-9]{3} [0-9]{4}$/;
  let regex5 = /^[0-9]{10}$/;
  let regex6 = /^1\([0-9]{3}\)[0-9]{3}-[0-9]{4}$/;

  //check for area code
if (str.match(/\d/g).length == 11 && str.match(/\d/g).join().substr(0,1) == 1) {
  let valid = str.slice(2, str.length);
  return regex1.test(valid) || regex2.test(valid) || regex3.test(valid)||regex4.test(valid)||regex5.test(valid)||regex6.test(str);
} 
  //10 str check
else if (str.match(/\d/g).length == 10) {
  return regex1.test(str) || regex2.test(str) || regex3.test(str)||regex4.test(str)||regex5.test(str);
  
}
  return false;
}

telephoneCheck("1 (555) 555-5555");