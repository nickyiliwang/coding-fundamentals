function sym(args) {
  let result = [];
  var sum = [];
  let repeating = [];

  for (let i = 0; i < arguments.length; i++) {
    sum.push(arguments[i]);
  }

  let masterA = [].concat.apply([], sum);
  let unique = [...new Set(masterA)];

unique.forEach(a => {
  sum.map(p => {
if (p.filter(x => x == a).length !== 1){
    return repeating.push(a);
  }
    return result.push(a);
  })
  
});

let final = [...new Set(repeating)]

return final;

}

sym([1, 2, 3, 3], [5, 2, 1, 4])