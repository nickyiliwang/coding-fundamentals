var Person = function(firstAndLast) {
  this.first = firstAndLast.split(' ')[0];
  this.last = firstAndLast.split(' ')[1];
  this.getFirstName = () => this.first;
  this.getLastName = () => this.last;
  this.getFullName = () => this.first + " " + this.last;
  this.setFirstName = (first) => this.first = first;
  this.setLastName = (last) => this.last = last;
  this.setFullName = (str) => {
    this.first = str.split(' ')[0];
    this.last = str.split(' ')[1];
  }
};

var bob = new Person('Bob Ross');
bob.setLastName("4th")
bob.getFullName();