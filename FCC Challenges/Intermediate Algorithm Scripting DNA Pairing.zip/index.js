function pairElement(str) {
let pairs = {
  "A" : "T",
  "T" : "A",
  "C" : "G",
  "G" : "C"
};

let newArr = str.split('').map(
x => [x, pairs[x]]

);




return newArr;

}

pairElement("GCG");