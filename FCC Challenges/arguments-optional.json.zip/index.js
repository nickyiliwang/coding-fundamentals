function addTogether(num) {
  //if 2 arguments exists, add 2 and 3 together
  if (arguments.length === 2 && Number.isInteger(arguments[0] + arguments[1])) { return arguments[0] + arguments[1]; }
  //else if theres only 1 argument return a function that adds both function
  else if (arguments.length === 1 && Number.isInteger(num)) {
    function hello(xD) {
      return Number.isInteger(num + xD) ? num + xD : undefined;
    }
    return hello;
  }

  //both arguments must be numbers, else return undefined
  return undefined;
}

addTogether(2, 3);