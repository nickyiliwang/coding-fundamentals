function palindrome(str) {
let n = str.toLowerCase();
let regex = /\w/gi;
let clean = n.match(regex).filter(x => x !== "_" );
let og = clean.join('');
let rev = clean.reverse().join('');

return og === rev ? true: false;
}

palindrome("nigger")