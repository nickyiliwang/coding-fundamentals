function sumFibs(num) {

let newArr = [0,1];
let fib = [];
fib[0] = 0;
fib[1] = 1;

//looping fibooby numbers
for (let i = 2; i <= 50; i++) {
  fib[i] = fib[i - 2] + fib[i - 1];
  newArr.push(fib[i]);
}

//filter train choo choo, get the sum of odd# less than num
let sumArr = newArr.filter(less => less <= num).filter(odd => odd %2 == 1).reduce((a,b) => a + b, 0);

return sumArr;
}

sumFibs(1000);