function translatePigLatin(str) {
let result = '';
let regex = /[aeiou]/gi;

if(str[0].match(regex)){
result = str + 'way';
}else if (str.match(regex) === null) {
result = str + 'ay'; 
}else{
let vowelPos = str.indexOf(str.match(regex)[0]);
result = str.slice(vowelPos) + str.slice(0, vowelPos) + 'ay';
}
return result;
}

translatePigLatin("consonant");