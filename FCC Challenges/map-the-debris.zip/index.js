function orbitalPeriod(arr) {
  var GM = 398600.4418;
  var earthRadius = 6367.4447;
//for each obj in the arr, calculat and return the name and its results
let newA = arr.map (x => {
  let n = x.name;
  let a = x.avgAlt;
  let p = 2 * Math.PI;
  let u = Math.sqrt(Math.pow(earthRadius + a, 3)/GM);
  let e = Math.round(u * p);
  let obj = {name: n, orbitalPeriod: e};
  return obj;
});
return newA;
}

orbitalPeriod([{name: "iss", avgAlt: 413.6}, {name: "hubble", avgAlt: 556.7}, {name: "moon", avgAlt: 378632.553}])