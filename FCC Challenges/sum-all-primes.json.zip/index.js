function sumPrimes(num) {
    var store  = [], i, j, primes = [];
    for (i = 2; i <= num; ++i) 
    {
        if (!store [i]) 
          {
            primes.push(i);
            for (j = i << 1; j <= num; j += i) 
            {
                store[j] = true;
            }
        }
    }




let sumA = primes.reduce((a, b) => (a + b));


  return sumA;
}

sumPrimes(4);