function whatIsInAName(collection, source) {
var arr = collection.filter(function(item){
for (let i in source) {
if (source[i] != item[i]){
  return false;
}
}
return true;
});
return arr;
}

whatIsInAName([{ "apple": 1, "bat": 2 }, { "bat": 2 }, { "apple": 1, "bat": 2, "cookie": 2 }], { "apple": 1, "bat": 2 });