function rot13(str) {
  let alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let newA = str.split('').map(x => alpha.indexOf(x));
  let adjA = newA.map(a => {
    if (a < 0) {
      return a + 0;
    } else if(a + 13 > 25){
      return a + 13 - 26} return a + 13;
    });

let result = adjA.map(o => alpha.charAt(o)).join(' ');
return result;
}

rot13("SERR CVMMN!")